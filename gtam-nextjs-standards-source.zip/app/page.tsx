import DashboardApp from '../src/components/DashboardApp'

export default function Page() {
  return <DashboardApp />
}
