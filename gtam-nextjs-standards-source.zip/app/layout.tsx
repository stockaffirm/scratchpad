import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'GTAM Insights',
  description: 'GTAM Insights dashboard',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
