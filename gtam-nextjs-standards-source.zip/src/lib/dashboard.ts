import { FALLBACK_DASHBOARD_DATA } from './fallbackData'

const GRAPHQL_ENDPOINT = process.env.NEXT_PUBLIC_GRAPHQL_ENDPOINT || '/api/graphql'
const USER_ENDPOINT = process.env.NEXT_PUBLIC_USER_ENDPOINT || '/api/user'

export const APPS_OPERATE_SUMMARY_QUERY = `
query AppsOperateSummary {
  digitamInsights {
    apps(useCache: true, state: "Operate") {
      byLobStateTgo { key count applicationIds }
      cpofByLobStateTgo(cpof: Y) { key count applicationIds }
      externalByLobStateTgo { key count applicationIds }
      builtByByLobStateTgo { key count applicationIds }
      runByByLobStateTgo { key count applicationIds }
      runOnByLobStateTgo { key count applicationIds }
    }
    compute(state: "Operate", useCache: true) {
      containerAppIds containerCount
      mobileAppIds mobileCount
      nonComputeAppIds nonComputeCount
      physicalAppIds physicalCount
      tbdAppIds tbdCount
      thirdPartyAppIds thirdPartyCount
      virtualAppIds virtualCount
    }
    infrastructure(state: "Operate", useCache: true) {
      awsOnlyAppIds awsOnlyCount
      hybridAppIds hybridCount
      mobileAppIds mobileCount
      noInfraAppIds noInfraCount
      privateOnlyAppIds privateOnlyCount
      thirdPartyAppIds thirdPartyCount
    }
    resiliency(state: "Operate", useCache: true) {
      multiAzAppIds multiAzCount
      multiRegionAppIds multiRegionCount
      saasOnlyExcludedAppIds saasOnlyExcludedCount
      singleAzAppIds singleAzCount
      singleRegionAppIds singleRegionCount
      thirdPartyExcludedAppIds thirdPartyExcludedCount
      nonComputeExcludedAppIds nonComputeExcludedCount
      mobileExcludedCount mobileExcludedAppIds
      unknownAppIds unknownCount
    }
  }
}
`

function percent(value, total) {
  if (!total) return '0.0%'
  return `${((value / total) * 100).toFixed(1)}%`
}

function sumCounts(rows) {
  return (rows || []).reduce((acc, row) => acc + (Number(row.count) || 0), 0)
}

function countByKeyMatch(rows, matcher) {
  return (rows || []).reduce((acc, row) => {
    if (matcher(String(row.key || '').toLowerCase())) {
      return acc + (Number(row.count) || 0)
    }
    return acc
  }, 0)
}

function inferFirstThirdParty(rows, total) {
  const thirdParty = countByKeyMatch(rows, (key) => key.includes('3') || key.includes('third'))
  const firstParty = Math.max(0, total - thirdParty)
  return { firstParty, thirdParty }
}

async function postGraphQL(query, variables = {}) {
  const response = await fetch(GRAPHQL_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query, variables }),
  })

  if (!response.ok) {
    throw new Error(`GraphQL request failed (${response.status})`)
  }

  const body = await response.json()
  if (body.errors?.length) {
    throw new Error(body.errors[0].message || 'GraphQL responded with errors')
  }

  return body.data
}

export async function fetchUserContext() {
  const response = await fetch(USER_ENDPOINT)
  if (!response.ok) {
    throw new Error(`User request failed (${response.status})`)
  }
  return response.json()
}

export async function fetchOperateSummaryRaw() {
  return postGraphQL(APPS_OPERATE_SUMMARY_QUERY)
}

export function mapOperateSummaryToDashboard(rawData, fallback = FALLBACK_DASHBOARD_DATA) {
  const insights = rawData?.digitamInsights
  if (!insights) {
    return fallback
  }

  const apps = insights.apps || {}
  const compute = insights.compute || {}
  const infra = insights.infrastructure || {}
  const resiliency = insights.resiliency || {}

  const totalApps = sumCounts(apps.byLobStateTgo)
  if (!totalApps) {
    return fallback
  }

  const cpofCount = sumCounts(apps.cpofByLobStateTgo)
  const externalCount = sumCounts(apps.externalByLobStateTgo)

  const builtByMix = inferFirstThirdParty(apps.builtByByLobStateTgo, totalApps)
  const runByMix = inferFirstThirdParty(apps.runByByLobStateTgo, totalApps)
  const runOnMix = inferFirstThirdParty(apps.runOnByLobStateTgo, totalApps)

  const onPrem = Number(infra.privateOnlyCount) || 0
  const publicCloud = Number(infra.awsOnlyCount) || 0
  const hybrid = Number(infra.hybridCount) || 0
  const external3p = Number(infra.thirdPartyCount) || externalCount

  const physicalCount = Number(compute.physicalCount) || 0
  const virtualCount = Number(compute.virtualCount) || 0
  const containerCount = Number(compute.containerCount) || 0

  const compliancePct = percent(cpofCount, totalApps)
  const thirdPartyPct = percent(external3p, totalApps)

  return {
    ...fallback,
    insightCards: [
      {
        ...fallback.insightCards[0],
        subtitle: `${Math.max(0, totalApps - cpofCount)} CPOF applications have dependencies on non-CPOF systems`,
      },
      {
        ...fallback.insightCards[1],
        subtitle: `${Number(resiliency.unknownCount) || 0} integrations discovered in production are not documented`,
      },
      fallback.insightCards[2],
      {
        ...fallback.insightCards[3],
        subtitle: `${thirdPartyPct} of applications run on 3rd party infrastructure`,
      },
      fallback.insightCards[4],
    ],
    keyMetrics: [
      fallback.keyMetrics[0],
      { ...fallback.keyMetrics[1], value: compliancePct },
      { ...fallback.keyMetrics[2], value: String(totalApps) },
      fallback.keyMetrics[3],
      fallback.keyMetrics[4],
      fallback.keyMetrics[5],
      {
        ...fallback.keyMetrics[6],
        value: percent(Number(resiliency.unknownCount) || 0, totalApps),
        delta: `${Number(resiliency.unknownCount) || 0} unmatched`,
      },
    ],
    ownership: {
      builtBy: [
        ['1st Party', builtByMix.firstParty, percent(builtByMix.firstParty, totalApps)],
        ['3rd Party', builtByMix.thirdParty, percent(builtByMix.thirdParty, totalApps)],
      ],
      runBy: [
        ['1st Party', runByMix.firstParty, percent(runByMix.firstParty, totalApps)],
        ['3rd Party', runByMix.thirdParty, percent(runByMix.thirdParty, totalApps)],
      ],
      runWhere: [
        ['1P Infrastructure', runOnMix.firstParty, percent(runOnMix.firstParty, totalApps)],
        ['3P Infrastructure', runOnMix.thirdParty, percent(runOnMix.thirdParty, totalApps)],
      ],
    },
    deployment: {
      ...fallback.deployment,
      totalApplications: totalApps,
      locationStats: [
        { label: 'On-Premise', value: onPrem, percent: percent(onPrem, totalApps) },
        { label: 'Public Cloud', value: publicCloud, percent: percent(publicCloud, totalApps) },
        { label: 'Hybrid', value: hybrid, percent: percent(hybrid, totalApps) },
        { label: 'External 3P', value: external3p, percent: percent(external3p, totalApps) },
      ],
      computeUsage: [
        { label: 'Physical', value: physicalCount, percent: percent(physicalCount, totalApps) },
        { label: 'Virtual', value: virtualCount, percent: percent(virtualCount, totalApps) },
        { label: 'Container', value: containerCount, percent: percent(containerCount, totalApps) },
      ],
      providerStats: [
        {
          ...fallback.deployment.providerStats[0],
          value: publicCloud,
        },
        ...fallback.deployment.providerStats.slice(1),
      ],
    },
  }
}

export async function loadDashboardData() {
  const raw = await fetchOperateSummaryRaw()
  return mapOperateSummaryToDashboard(raw)
}
