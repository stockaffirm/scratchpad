'use client'

import React from 'react'
import { useEffect, useMemo, useState } from 'react'
import {
  AppBar,
  Box,
  Button,
  Card,
  CardContent,
  Container,
  Divider,
  FormControl,
  Grid2 as Grid,
  IconButton,
  MenuItem,
  Paper,
  Select,
  Stack,
  Tab,
  Tabs,
  Toolbar,
  Typography,
} from '@mui/material'
import AlertTriangleIcon from '@mui/icons-material/WarningAmberRounded'
import CheckIcon from '@mui/icons-material/CheckCircleRounded'
import InfoIcon from '@mui/icons-material/InfoRounded'
import BoltIcon from '@mui/icons-material/BoltRounded'
import DownloadIcon from '@mui/icons-material/FileDownloadOutlined'
import HelpOutlineIcon from '@mui/icons-material/HelpOutline'
import { FALLBACK_DASHBOARD_DATA } from '../lib/fallbackData'
import { fetchUserContext, loadDashboardData } from '../lib/dashboard'

const tabs = [
  'Overview',
  'Where Are Apps Deployed?',
  'Who Owns & Runs Apps?',
  'Which Apps Are Critical?',
  'Resilience Status',
  'App Connections',
  'Technology Stack',
  'Take Action',
]

const COLORS = {
  blue: '#106bc5',
  purple: '#7751b3',
  green: '#4d9641',
  orange: '#d2962d',
  red: '#c73e33',
}

const insightDetails = {
  'CPOF Compliance Violations Detected': {
    impact: 'Critical compliance risk - CPOF isolation requirements violated',
    recommendation: 'Review CPOF dependencies and create remediation plans',
  },
  'Configuration Drift Detected': {
    impact: '16.1% documentation gap - Security & compliance risk',
    recommendation: 'Review undocumented integrations in App Connections view',
  },
  'Critical Vulnerabilities Require Attention': {
    impact: 'High Security Risk - Immediate remediation required',
    recommendation: 'Prioritize patching for critical applications',
  },
  'Third-Party Infrastructure Growing': {
    impact: 'Cost & vendor lock-in considerations',
    recommendation: 'Review in "Who Owns & Runs Apps?" for optimization opportunities',
  },
  'Resilience Score Improved': {
    impact: 'Reduced incident risk and improved SLA compliance',
    recommendation: 'Continue resilience testing best practices',
  },
}

const resilienceData = {
  azMix: [
    { label: 'AZ Resilient', percent: 57.3, color: COLORS.purple },
    { label: 'Regional Resilient', percent: 25.5, color: COLORS.green },
    { label: 'Not Resilient', percent: 17.1, color: '#4a7fa8' },
  ],
  testSuccess: [
    { label: 'Successful', percent: 85.9, color: COLORS.purple },
    { label: 'Unsuccessful', percent: 14.1, color: COLORS.green },
  ],
  recentTests: [
    { name: 'Payment API', date: '2026-01-15', type: 'AZ Failover', result: 'Recovery Time: 4m 32s', good: true },
    { name: 'Fraud Detection', date: '2026-01-12', type: 'Regional Failover', result: 'Recovery Time: 2m 18s', good: true },
    { name: 'Customer Portal', date: '2026-01-10', type: 'AZ Failover', result: 'Failure Reason: Database connection timeout', good: false },
    { name: 'Analytics Engine', date: '2026-01-08', type: 'AZ Failover', result: 'Recovery Time: 6m 45s', good: true },
  ],
  upcoming: [
    { name: 'Trading Platform', schedule: '2026-02-15', type: 'Regional Failover' },
    { name: 'Risk Calculator', schedule: '2026-02-18', type: 'AZ Failover' },
  ],
}

const appConnectionsData = {
  overview: [
    { label: 'Total Integrations', value: 342, detail: 'Across all applications', color: '#111827' },
    { label: 'Declared Integrations', value: 287, detail: 'Documented in DNA/SEAL/CIA', color: COLORS.green },
    { label: 'Configuration Drift', value: 55, detail: 'Discovered but not declared', color: COLORS.orange },
    { label: 'Drift Percentage', value: '16.1%', detail: 'Accuracy gap', color: COLORS.orange },
  ],
  coverage: [
    { name: 'DNA', integrations: 287, pct: 95, tone: '#22c55e', type: 'Declared Flows' },
    { name: 'SEAL', integrations: 287, pct: 98, tone: '#22c55e', type: 'Declared Flows' },
    { name: 'MQ', integrations: 215, pct: 78, tone: COLORS.blue, type: 'Discovered Flows' },
    { name: 'Dynatrace', integrations: 178, pct: 62, tone: '#f59e0b', type: 'Discovered Flows' },
    { name: 'CIA', integrations: 129, pct: 45, tone: '#f59e0b', type: 'Declared Flows' },
  ],
  recommendations: [
    { title: '1. Update Architecture Documentation', body: 'Review and document the 55 undocumented integrations discovered in production monitoring.' },
    { title: '2. Increase Monitoring Coverage', body: 'Improve MQ and Dynatrace coverage to capture all integration flows across the portfolio.' },
    { title: '3. Security Review Required', body: 'Undocumented integrations may pose security risks. Conduct security assessment for drift items.' },
    { title: '4. Governance Process', body: 'Establish automated drift detection alerts to maintain documentation accuracy.' },
  ],
}

function iconByType(type) {
  if (type === 'success') return <CheckIcon sx={{ color: '#22c55e', fontSize: 18 }} />
  if (type === 'info') return <InfoIcon sx={{ color: '#60a5fa', fontSize: 18 }} />
  if (type === 'warning-alt') return <BoltIcon sx={{ color: '#f59e0b', fontSize: 18 }} />
  return <AlertTriangleIcon sx={{ color: '#f59e0b', fontSize: 18 }} />
}

function percent(value, total) {
  if (!total) return 0
  return (value / total) * 100
}

function MainHeader({ activeTab, onTabChange }) {
  return (
    <AppBar position="sticky" elevation={0} sx={{ bgcolor: '#fff', color: '#111827', borderBottom: '1px solid #d9d9de' }}>
      <Toolbar sx={{ minHeight: 72, borderBottom: '1px solid #e7e7eb' }}>
        <Stack>
          <Typography sx={{ fontSize: 46, fontWeight: 800, letterSpacing: '-.03em', lineHeight: 0.9 }}>GTAM</Typography>
          <Typography sx={{ fontSize: 16, letterSpacing: '.28em', color: '#4b5563', mt: -0.2 }}>INSIGHTS</Typography>
        </Stack>
        <Box sx={{ flexGrow: 1 }} />
        <Button variant="outlined" startIcon={<DownloadIcon />} sx={{ borderRadius: 8, textTransform: 'none', fontWeight: 600, px: 2.5, mr: 3, color: '#111827', borderColor: '#111827' }}>
          Export to Excel
        </Button>
        <Stack>
          <Typography sx={{ fontSize: 36, fontWeight: 700, letterSpacing: '-.03em', lineHeight: 0.95 }}>Sri Shivananda</Typography>
          <Typography sx={{ fontSize: 20, color: '#6b7280', letterSpacing: '.04em' }}>PORTFOLIO OWNER</Typography>
        </Stack>
      </Toolbar>
      <Toolbar sx={{ minHeight: 56 }}>
        <Tabs
          value={activeTab}
          onChange={onTabChange}
          variant="scrollable"
          scrollButtons="auto"
          sx={{
            '& .MuiTab-root': {
              textTransform: 'none',
              fontWeight: 600,
              fontSize: 14,
              minHeight: 56,
              px: 2,
              color: '#374151',
            },
            '& .Mui-selected': { color: '#111827' },
          }}
        >
          {tabs.map((label) => <Tab key={label} label={label} />)}
        </Tabs>
      </Toolbar>
    </AppBar>
  )
}

function FilterRow({ data, lob, product, setLob, setProduct }) {
  return (
    <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ py: 2 }}>
      <Typography sx={{ fontSize: 18, fontWeight: 500 }}>{data.greeting}</Typography>
      <Stack direction="row" spacing={2} alignItems="center">
        <Typography sx={{ fontSize: 16, color: '#6b7280' }}>LOB:</Typography>
        <FormControl size="small" sx={{ minWidth: 160 }}>
          <Select value={lob} onChange={(e) => setLob(e.target.value)}>
            <MenuItem value="CIB">CIB</MenuItem>
            <MenuItem value="CB">CB</MenuItem>
            <MenuItem value="Consumer">Consumer</MenuItem>
          </Select>
        </FormControl>
        <Typography sx={{ fontSize: 16, color: '#6b7280', ml: 1 }}>Product:</Typography>
        <FormControl size="small" sx={{ minWidth: 170 }}>
          <Select value={product} onChange={(e) => setProduct(e.target.value)}>
            <MenuItem value="ALL">ALL</MenuItem>
            <MenuItem value="Payments">Payments</MenuItem>
            <MenuItem value="Lending">Lending</MenuItem>
          </Select>
        </FormControl>
      </Stack>
    </Stack>
  )
}

function InsightCard({ item }) {
  const detail = insightDetails[item.title]
  return (
    <Card variant="outlined" sx={{ borderRadius: 2.5, borderColor: '#cbccd1', height: '100%' }}>
      <CardContent sx={{ p: 2 }}>
        <Stack spacing={1.6}>
          <Stack direction="row" spacing={1.2} alignItems="center">
            <Box sx={{ width: 30, height: 30, borderRadius: 1.5, bgcolor: '#fff5eb', display: 'grid', placeItems: 'center' }}>
              {iconByType(item.type)}
            </Box>
            <Typography sx={{ fontSize: 18, fontWeight: 700 }}>{item.title}</Typography>
          </Stack>
          <Typography sx={{ fontSize: 14.5 }}>{item.subtitle}</Typography>
          <Paper elevation={0} sx={{ bgcolor: '#f3f4f6', px: 1.4, py: 1, borderRadius: 1 }}>
            <Typography sx={{ fontSize: 14 }}><Box component="span" sx={{ fontWeight: 700 }}>Impact:</Box> {detail?.impact}</Typography>
          </Paper>
          <Typography sx={{ fontSize: 14, fontWeight: 700 }}>Recommended Action:</Typography>
          <Typography sx={{ fontSize: 14.5 }}>{detail?.recommendation}</Typography>
          <Button variant="contained" sx={{ bgcolor: '#000', borderRadius: 8, textTransform: 'none', fontWeight: 700, '&:hover': { bgcolor: '#111' } }}>{item.action}</Button>
        </Stack>
      </CardContent>
    </Card>
  )
}

function MetricCard({ item }) {
  return (
    <Paper variant="outlined" sx={{ p: 1.8, minHeight: 136, borderRadius: 2, borderColor: '#cbccd1' }}>
      <Stack spacing={1.4}>
        <Stack direction="row" justifyContent="space-between" alignItems="start">
          <Typography sx={{ fontSize: 12, fontWeight: 700, color: '#6b7280', textTransform: 'uppercase' }}>{item.label}</Typography>
          <IconButton size="small" sx={{ p: 0.2 }}><HelpOutlineIcon sx={{ fontSize: 17 }} /></IconButton>
        </Stack>
        <Typography sx={{ fontSize: 40, lineHeight: 1, fontWeight: 700 }}>{item.value}</Typography>
        <Typography sx={{ fontSize: 13.5, color: item.tone, fontWeight: 700 }}>{item.delta} <Box component="span" sx={{ color: '#6b7280', fontWeight: 500 }}>vs last month</Box></Typography>
      </Stack>
    </Paper>
  )
}

function OwnershipCard({ title, items }) {
  return (
    <Paper variant="outlined" sx={{ p: 2, borderRadius: 2.5, borderColor: '#cbccd1' }}>
      <Typography sx={{ fontSize: 18, fontWeight: 700, mb: 1.4 }}>{title}</Typography>
      <Stack spacing={1}>
        {items.map(([label, count, pct]) => (
          <Stack key={label} direction="row" justifyContent="space-between" alignItems="center" sx={{ bgcolor: '#f4f5f7', borderRadius: 1.5, px: 1.4, py: 1 }}>
            <Typography sx={{ fontSize: 14 }}>{label}</Typography>
            <Typography sx={{ fontSize: 14, fontWeight: 600 }}>{count}</Typography>
            <Typography sx={{ fontSize: 14, color: '#c97f31' }}>{pct}</Typography>
          </Stack>
        ))}
      </Stack>
    </Paper>
  )
}

function SmallStatCard({
  label,
  value,
  percentLabel,
  helper,
}: {
  label: string
  value: number | string
  percentLabel: string
  helper?: string
}) {
  return (
    <Paper variant="outlined" sx={{ p: 1.2, borderRadius: 2, borderColor: '#cbccd1', minHeight: 92 }}>
      <Typography sx={{ fontSize: 12, color: '#6b7280' }}>{label}</Typography>
      <Typography sx={{ fontSize: 38, lineHeight: 1.1, fontWeight: 700 }}>{value}</Typography>
      <Typography sx={{ fontSize: 12, color: '#c97f31' }}>{percentLabel}</Typography>
      {helper ? <Typography sx={{ fontSize: 11, color: '#6b7280' }}>{helper}</Typography> : null}
    </Paper>
  )
}

function SimpleBarChart({ data }) {
  const maxValue = useMemo(() => Math.max(...data.map((d) => d.value), 1), [data])
  return (
    <Stack spacing={1.2}>
      {data.map((item) => (
        <Stack key={item.region} direction="row" spacing={1} alignItems="center">
          <Typography sx={{ width: 74, fontSize: 12 }}>{item.region}</Typography>
          <Box sx={{ flexGrow: 1, bgcolor: '#edf0f4', borderRadius: 1, height: 18, overflow: 'hidden' }}>
            <Box sx={{ width: `${(item.value / maxValue) * 100}%`, bgcolor: COLORS.blue, height: '100%' }} />
          </Box>
          <Typography sx={{ width: 40, textAlign: 'right', fontWeight: 700, fontSize: 12 }}>{item.value}</Typography>
        </Stack>
      ))}
    </Stack>
  )
}

function PieChart({ series, size = 220 }) {
  const gradient = useMemo(() => {
    let angle = 0
    const parts = series.map((s) => {
      const start = angle
      const end = angle + (s.percent / 100) * 360
      angle = end
      return `${s.color} ${start}deg ${end}deg`
    })
    return `conic-gradient(${parts.join(', ')})`
  }, [series])

  return <Box sx={{ width: size, height: size, borderRadius: '50%', background: gradient }} />
}

function OverviewPage({ data }) {
  return (
    <Stack spacing={3}>
      <Box>
        <Typography sx={{ fontSize: 54, fontWeight: 800, letterSpacing: '-.03em', lineHeight: 1 }}>GTAM Insights</Typography>
        <Typography sx={{ fontSize: 16, color: '#6b7280' }}>Last updated: {data.lastUpdated}</Typography>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 38, fontWeight: 800, mb: 1.2, letterSpacing: '-.02em' }}>Actionable Insights</Typography>
        <Grid container spacing={2}>
          {data.insightCards.map((item) => (
            <Grid key={item.title} size={{ xs: 12, md: 6, lg: 4 }}>
              <InsightCard item={item} />
            </Grid>
          ))}
        </Grid>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 38, fontWeight: 800, mb: 1.2, letterSpacing: '-.02em' }}>Key Metrics</Typography>
        <Grid container spacing={1.5}>
          {data.keyMetrics.map((item) => (
            <Grid key={item.label} size={{ xs: 12, sm: 6, md: 4, lg: 2.4 }}>
              <MetricCard item={item} />
            </Grid>
          ))}
        </Grid>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 38, fontWeight: 800, mb: 1.2, letterSpacing: '-.02em' }}>Ownership & Operations</Typography>
        <Grid container spacing={2}>
          <Grid size={{ xs: 12, md: 4 }}><OwnershipCard title="Built By" items={data.ownership.builtBy} /></Grid>
          <Grid size={{ xs: 12, md: 4 }}><OwnershipCard title="Run By" items={data.ownership.runBy} /></Grid>
          <Grid size={{ xs: 12, md: 4 }}><OwnershipCard title="Run Where" items={data.ownership.runWhere} /></Grid>
        </Grid>
      </Box>
    </Stack>
  )
}

function DeploymentPage({ data }) {
  const d = data.deployment
  const locationSeries = d.locationStats.map((item, index) => ({ ...item, color: [COLORS.purple, COLORS.green, '#3e7aac', COLORS.red][index] }))
  return (
    <Stack spacing={2.4}>
      <Box>
        <Typography sx={{ fontSize: 52, fontWeight: 800, letterSpacing: '-.03em', lineHeight: 1 }}>Where Are Applications Deployed?</Typography>
        <Typography sx={{ fontSize: 16, color: '#6b7280' }}>Physical deployment locations, regions, datacenters, and compute platforms</Typography>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 22, fontWeight: 700, mb: 1 }}>Deployment Locations ({d.totalApplications} Total Applications)</Typography>
        <Grid container spacing={1.2}>
          {d.locationStats.map((item) => (
            <Grid key={item.label} size={{ xs: 12, sm: 6, md: 3 }}>
              <SmallStatCard label={item.label} value={item.value} percentLabel={item.percent} />
            </Grid>
          ))}
        </Grid>
      </Box>

      <Grid container spacing={1.6}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Typography sx={{ fontSize: 19, fontWeight: 700, mb: 1 }}>Deployment Distribution by Location Type</Typography>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 2.5, borderColor: '#cbccd1', minHeight: 316 }}>
            <Stack direction="row" spacing={2} alignItems="center">
              <PieChart series={locationSeries.map((item) => ({ percent: Number(item.percent.replace('%', '')), color: item.color }))} size={220} />
              <Stack>
                {locationSeries.map((item) => (
                  <Stack key={item.label} direction="row" spacing={1} alignItems="center">
                    <Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: item.color }} />
                    <Typography sx={{ fontSize: 12 }}>{item.label}</Typography>
                    <Typography sx={{ fontSize: 12, color: '#6b7280' }}>{item.percent}</Typography>
                  </Stack>
                ))}
              </Stack>
            </Stack>
          </Paper>
        </Grid>
        <Grid size={{ xs: 12, md: 6 }}>
          <Typography sx={{ fontSize: 19, fontWeight: 700, mb: 1 }}>Geographic Distribution by Region</Typography>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 2.5, borderColor: '#cbccd1', minHeight: 316 }}>
            <SimpleBarChart data={d.regionStats} />
          </Paper>
        </Grid>
      </Grid>

      <Box>
        <Typography sx={{ fontSize: 20, fontWeight: 700, mb: 1 }}>Regional Distribution Details</Typography>
        <Grid container spacing={1.2}>
          {d.regionStats.map((item) => (
            <Grid key={item.region} size={{ xs: 12, sm: 6, md: 3 }}>
              <SmallStatCard label={item.region} value={item.value} percentLabel={item.percent} helper={`${item.datacenters} datacenters`} />
            </Grid>
          ))}
        </Grid>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 20, fontWeight: 700, mb: 1 }}>Datacenter Concentrations</Typography>
        <Grid container spacing={1.2}>
          {d.datacenterConcentrations.map((text) => (
            <Grid key={text} size={{ xs: 12, md: 6 }}>
              <Paper variant="outlined" sx={{ p: 1.3, borderRadius: 1.5, borderColor: '#cbccd1' }}><Typography sx={{ fontSize: 14 }}>{text}</Typography></Paper>
            </Grid>
          ))}
        </Grid>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 20, fontWeight: 700, mb: 1 }}>Compute Platform Usage</Typography>
        <Grid container spacing={1.2}>
          {d.computeUsage.map((item) => (
            <Grid key={item.label} size={{ xs: 12, md: 4 }}>
              <SmallStatCard label={item.label} value={item.value} percentLabel={item.percent} />
            </Grid>
          ))}
        </Grid>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 20, fontWeight: 700, mb: 1 }}>Detailed Platform Breakdown</Typography>
        <Grid container spacing={1.2}>
          <Grid size={{ xs: 12, md: 6 }}>
            <Paper variant="outlined" sx={{ p: 2, borderRadius: 2.5, borderColor: '#cbccd1', minHeight: 420 }}>
              <SimpleBarChart data={d.platformStats.map((item) => ({ region: item.name, value: item.count }))} />
            </Paper>
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <Stack spacing={1}>
              {d.platformStats.map((item) => (
                <Paper key={item.name} variant="outlined" sx={{ p: 1.2, borderRadius: 1.8, borderColor: '#cbccd1' }}>
                  <Typography sx={{ fontSize: 16, fontWeight: 600 }}>{item.name}</Typography>
                  <Typography sx={{ fontSize: 22 }}>{item.count}</Typography>
                  <Typography sx={{ fontSize: 12, color: '#6b7280' }}>{percent(item.count, d.totalApplications).toFixed(1)}% of portfolio</Typography>
                </Paper>
              ))}
            </Stack>
          </Grid>
        </Grid>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 20, fontWeight: 700, mb: 1 }}>Public Cloud Provider Distribution</Typography>
        <Grid container spacing={1.2}>
          {d.providerStats.map((item) => (
            <Grid key={item.name} size={{ xs: 12, md: 4 }}>
              <Paper variant="outlined" sx={{ p: 1.3, borderRadius: 1.8, borderColor: '#cbccd1' }}>
                <Typography sx={{ fontSize: 18, fontWeight: 600 }}>{item.name}</Typography>
                <Typography sx={{ fontSize: 40, lineHeight: 1 }}>{item.value}</Typography>
                <Typography sx={{ fontSize: 12, color: '#6b7280' }}>{item.detail}</Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Stack>
  )
}

function WhoOwnsPage({ data }) {
  const total = data.deployment.totalApplications
  const rows = [
    { label: 'Built By', first: data.ownership.builtBy[0][1], third: data.ownership.builtBy[1][1] },
    { label: 'Run By', first: data.ownership.runBy[0][1], third: data.ownership.runBy[1][1] },
    { label: 'Run Where', first: data.ownership.runWhere[0][1], third: data.ownership.runWhere[1][1] },
  ]

  return (
    <Stack spacing={2.4}>
      <Box>
        <Typography sx={{ fontSize: 52, fontWeight: 800, letterSpacing: '-.03em', lineHeight: 1 }}>Who Owns & Runs Applications?</Typography>
        <Typography sx={{ fontSize: 16, color: '#6b7280' }}>Understanding the ownership and operational model of your portfolio</Typography>
      </Box>

      <Paper variant="outlined" sx={{ p: 1.8, borderRadius: 2, borderColor: '#cbccd1' }}>
        <Typography sx={{ fontSize: 28, fontWeight: 700 }}>Key Question Answered</Typography>
        <Typography sx={{ fontSize: 16, mt: 0.5, fontWeight: 600 }}>Where is my application run, who owns the application code, and who built and maintains it?</Typography>
        <Typography sx={{ fontSize: 14, color: '#6b7280', mt: 1 }}>This view shows the declared ownership model: applications run on 1P vs 3P infrastructure, built by 1P vs 3P teams, and operated by 1P vs 3P resources.</Typography>
      </Paper>

      <Box>
        <Typography sx={{ fontSize: 36, fontWeight: 800, mb: 1.2 }}>Ownership Model Overview</Typography>
        <Grid container spacing={1.2}>
          <Grid size={{ xs: 12, md: 4 }}><SmallStatCard label="1st Party Built" value={data.ownership.builtBy[0][1]} percentLabel={data.ownership.builtBy[0][2]} helper="of portfolio" /></Grid>
          <Grid size={{ xs: 12, md: 4 }}><SmallStatCard label="1st Party Operated" value={data.ownership.runBy[0][1]} percentLabel={data.ownership.runBy[0][2]} helper="of portfolio" /></Grid>
          <Grid size={{ xs: 12, md: 4 }}><SmallStatCard label="1st Party Infrastructure" value={data.ownership.runWhere[0][1]} percentLabel={data.ownership.runWhere[0][2]} helper="of portfolio" /></Grid>
        </Grid>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 36, fontWeight: 800, mb: 1.2 }}>1st Party vs 3rd Party Breakdown</Typography>
        <Paper variant="outlined" sx={{ p: 2.2, borderRadius: 2.5, borderColor: '#cbccd1' }}>
          <Stack spacing={2}>
            {rows.map((row) => (
              <Stack key={row.label} spacing={0.5}>
                <Typography sx={{ fontSize: 14, fontWeight: 700 }}>{row.label}</Typography>
                <Box sx={{ height: 32, borderRadius: 1, bgcolor: '#e6e9ef', overflow: 'hidden', display: 'flex' }}>
                  <Box sx={{ width: `${percent(row.third, total)}%`, bgcolor: COLORS.purple, display: 'grid', placeItems: 'center', color: '#fff', fontSize: 13, fontWeight: 700 }}>{row.third}</Box>
                  <Box sx={{ width: `${percent(row.first, total)}%`, bgcolor: '#44729a', display: 'grid', placeItems: 'center', color: '#fff', fontSize: 13, fontWeight: 700 }}>{row.first}</Box>
                </Box>
              </Stack>
            ))}
            <Stack direction="row" spacing={2} justifyContent="center">
              <Stack direction="row" spacing={0.8} alignItems="center"><Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: '#44729a' }} /><Typography sx={{ fontSize: 14 }}>1st Party</Typography></Stack>
              <Stack direction="row" spacing={0.8} alignItems="center"><Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: COLORS.purple }} /><Typography sx={{ fontSize: 14 }}>3rd Party</Typography></Stack>
            </Stack>
          </Stack>
        </Paper>
      </Box>
    </Stack>
  )
}

function ResiliencePage() {
  return (
    <Stack spacing={2.4}>
      <Typography sx={{ fontSize: 52, fontWeight: 800, letterSpacing: '-.03em', lineHeight: 1 }}>Resilience Status</Typography>
      <Grid container spacing={1.5}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 2.5, borderColor: '#cbccd1' }}>
            <Stack direction="row" spacing={2} alignItems="center">
              <PieChart series={resilienceData.azMix} size={210} />
              <Stack>
                {resilienceData.azMix.map((item) => (
                  <Stack key={item.label} direction="row" spacing={1} alignItems="center"><Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: item.color }} /><Typography sx={{ fontSize: 14 }}>{item.label}: {item.percent}%</Typography></Stack>
                ))}
              </Stack>
            </Stack>
          </Paper>
        </Grid>
        <Grid size={{ xs: 12, md: 6 }}>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 2.5, borderColor: '#cbccd1' }}>
            <Stack direction="row" spacing={2} alignItems="center">
              <PieChart series={resilienceData.testSuccess} size={210} />
              <Stack>
                {resilienceData.testSuccess.map((item) => (
                  <Stack key={item.label} direction="row" spacing={1} alignItems="center"><Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: item.color }} /><Typography sx={{ fontSize: 14 }}>{item.label}: {item.percent}%</Typography></Stack>
                ))}
              </Stack>
            </Stack>
          </Paper>
        </Grid>
      </Grid>

      <Box>
        <Typography sx={{ fontSize: 30, fontWeight: 800, mb: 1 }}>Recent Resilience Tests</Typography>
        <Stack spacing={1}>
          {resilienceData.recentTests.map((test) => (
            <Paper key={test.name} variant="outlined" sx={{ p: 1.2, borderRadius: 1.8, borderColor: '#cbccd1' }}>
              <Typography sx={{ fontSize: 18, fontWeight: 700 }}>{test.name}</Typography>
              <Typography sx={{ fontSize: 12, color: '#6b7280' }}>{test.date} - {test.type}</Typography>
              <Typography sx={{ fontSize: 14, mt: 1, color: test.good ? '#111827' : '#b45309', fontWeight: 700 }}>{test.result}</Typography>
            </Paper>
          ))}
        </Stack>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 30, fontWeight: 800, mb: 1 }}>Upcoming Tests</Typography>
        <Grid container spacing={1.2}>
          {resilienceData.upcoming.map((test) => (
            <Grid key={test.name} size={{ xs: 12, md: 6 }}>
              <Paper variant="outlined" sx={{ p: 1.2, borderRadius: 1.8, borderColor: '#cbccd1' }}>
                <Typography sx={{ fontSize: 18, fontWeight: 700 }}>{test.name}</Typography>
                <Typography sx={{ fontSize: 14 }}><Box component="span" sx={{ fontWeight: 700 }}>Scheduled:</Box> {test.schedule}</Typography>
                <Typography sx={{ fontSize: 12, color: '#6b7280' }}>{test.type}</Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Stack>
  )
}

function AppConnectionsPage() {
  return (
    <Stack spacing={2.4}>
      <Box>
        <Typography sx={{ fontSize: 52, fontWeight: 800, letterSpacing: '-.03em', lineHeight: 1 }}>Application Connections & Integration Flows</Typography>
        <Typography sx={{ fontSize: 16, color: '#6b7280' }}>Understanding how applications share information across your portfolio</Typography>
      </Box>

      <Paper variant="outlined" sx={{ p: 1.8, borderRadius: 2, borderColor: '#cbccd1' }}>
        <Typography sx={{ fontSize: 28, fontWeight: 700 }}>Key Question Answered</Typography>
        <Typography sx={{ fontSize: 16, mt: 0.5, fontWeight: 600 }}>What other applications is my application sharing information with?</Typography>
        <Typography sx={{ fontSize: 14, color: '#6b7280', mt: 1 }}>This view compares declared flows (DNA, SEAL, CIA) vs discovered flows (MQ, Dynatrace) to identify configuration drift and undocumented integrations.</Typography>
      </Paper>

      <Box>
        <Typography sx={{ fontSize: 34, fontWeight: 800, mb: 1 }}>Integration Overview</Typography>
        <Grid container spacing={1.2}>
          {appConnectionsData.overview.map((item) => (
            <Grid key={item.label} size={{ xs: 12, md: 3 }}>
              <Paper variant="outlined" sx={{ p: 1.2, borderRadius: 2, borderColor: '#cbccd1' }}>
                <Typography sx={{ fontSize: 14, color: '#6b7280' }}>{item.label}</Typography>
                <Typography sx={{ fontSize: 36, color: item.color }}>{item.value}</Typography>
                <Typography sx={{ fontSize: 13 }}>{item.detail}</Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 34, fontWeight: 800, mb: 1 }}>Configuration Drift Analysis</Typography>
        <Grid container spacing={1.2}>
          <Grid size={{ xs: 12, md: 6 }}>
            <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, borderColor: '#cbccd1', minHeight: 338 }}>
              <Stack alignItems="center" spacing={2}>
                <PieChart series={[{ percent: 83.9, color: COLORS.green }, { percent: 16.1, color: COLORS.orange }]} size={190} />
                <Stack direction="row" spacing={2}>
                  <Stack direction="row" spacing={0.6} alignItems="center"><Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: COLORS.green }} /><Typography sx={{ fontSize: 14 }}>Verified (Declared & Discovered)</Typography></Stack>
                  <Stack direction="row" spacing={0.6} alignItems="center"><Box sx={{ width: 10, height: 10, borderRadius: '50%', bgcolor: COLORS.orange }} /><Typography sx={{ fontSize: 14 }}>Unmatched (Drift)</Typography></Stack>
                </Stack>
              </Stack>
            </Paper>
          </Grid>
          <Grid size={{ xs: 12, md: 6 }}>
            <Stack spacing={1.1}>
              <Paper variant="outlined" sx={{ p: 1.2, borderRadius: 1.8, borderColor: '#cbccd1' }}>
                <Typography sx={{ color: COLORS.green, fontSize: 20, fontWeight: 700 }}>Verified Integrations</Typography>
                <Typography sx={{ fontSize: 32 }}>287</Typography>
                <Typography sx={{ fontSize: 13, color: '#6b7280' }}>These integrations are both declared in architecture documents and discovered in runtime monitoring.</Typography>
              </Paper>
              <Paper variant="outlined" sx={{ p: 1.2, borderRadius: 1.8, borderColor: '#cbccd1' }}>
                <Typography sx={{ color: COLORS.orange, fontSize: 20, fontWeight: 700 }}>Configuration Drift</Typography>
                <Typography sx={{ fontSize: 32 }}>55</Typography>
                <Typography sx={{ fontSize: 13, color: '#6b7280' }}>These integrations were discovered in production but are not documented in architecture repositories.</Typography>
              </Paper>
            </Stack>
          </Grid>
        </Grid>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 34, fontWeight: 800, mb: 1 }}>Data Source Coverage</Typography>
        <Stack spacing={1}>
          {appConnectionsData.coverage.map((item) => (
            <Paper key={item.name} variant="outlined" sx={{ p: 1.1, borderRadius: 1.8, borderColor: '#cbccd1' }}>
              <Stack direction="row" justifyContent="space-between">
                <Typography sx={{ fontSize: 20 }}>{item.name}</Typography>
                <Typography sx={{ fontSize: 20, color: '#b97c30' }}>{item.integrations}</Typography>
              </Stack>
              <Stack direction="row" justifyContent="space-between" sx={{ mt: 0.2 }}>
                <Typography sx={{ fontSize: 14, color: '#6b7280' }}>{item.type}</Typography>
                <Typography sx={{ fontSize: 14, color: '#6b7280' }}>Integrations</Typography>
              </Stack>
              <Box sx={{ mt: 1.1, height: 10, borderRadius: 10, bgcolor: '#e5e7eb', overflow: 'hidden' }}>
                <Box sx={{ width: `${item.pct}%`, height: '100%', bgcolor: item.tone }} />
              </Box>
              <Typography sx={{ textAlign: 'right', mt: 0.4, fontSize: 14, fontWeight: 700 }}>{item.pct}%</Typography>
            </Paper>
          ))}
        </Stack>
      </Box>

      <Box>
        <Typography sx={{ fontSize: 34, fontWeight: 800, mb: 1 }}>Recommended Actions</Typography>
        <Grid container spacing={1.2}>
          {appConnectionsData.recommendations.map((item) => (
            <Grid key={item.title} size={{ xs: 12, md: 6 }}>
              <Paper variant="outlined" sx={{ p: 1.2, borderRadius: 1.8, borderColor: '#cbccd1' }}>
                <Typography sx={{ fontSize: 16, fontWeight: 700 }}>{item.title}</Typography>
                <Typography sx={{ fontSize: 13.5, color: '#6b7280' }}>{item.body}</Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Stack>
  )
}

function PlaceholderPage({ title }) {
  return <Typography sx={{ fontSize: 36, fontWeight: 700 }}>{title} page layout pending.</Typography>
}

export default function DashboardApp() {
  const [activeTab, setActiveTab] = useState(0)
  const [lob, setLob] = useState('CIB')
  const [product, setProduct] = useState('ALL')
  const [dashboardData, setDashboardData] = useState(FALLBACK_DASHBOARD_DATA)

  useEffect(() => {
    async function loadData() {
      const [summary, user] = await Promise.allSettled([loadDashboardData(), fetchUserContext()])

      if (summary.status === 'fulfilled') {
        setDashboardData((prev) => ({ ...prev, ...summary.value }))
      }

      if (user.status === 'fulfilled') {
        setDashboardData((prev) => ({
          ...prev,
          greeting: user.value?.greeting || prev.greeting,
          lob: user.value?.lob || prev.lob,
          product: user.value?.product || prev.product,
        }))
        setLob(user.value?.lob || 'CIB')
        setProduct(user.value?.product || 'ALL')
      }
    }

    loadData()
  }, [])

  return (
    <Box sx={{ minHeight: '100vh', bgcolor: '#f3f4f6' }}>
      <MainHeader activeTab={activeTab} onTabChange={(_, v) => setActiveTab(v)} />
      <Container maxWidth={false} sx={{ px: 3, py: 1.2 }}>
        <FilterRow data={dashboardData} lob={lob} product={product} setLob={setLob} setProduct={setProduct} />
        <Divider sx={{ mb: 2 }} />

        {activeTab === 0 && <OverviewPage data={dashboardData} />}
        {activeTab === 1 && <DeploymentPage data={dashboardData} />}
        {activeTab === 2 && <WhoOwnsPage data={dashboardData} />}
        {activeTab === 3 && <PlaceholderPage title="Which Apps Are Critical?" />}
        {activeTab === 4 && <ResiliencePage />}
        {activeTab === 5 && <AppConnectionsPage />}
        {activeTab === 6 && <PlaceholderPage title="Technology Stack" />}
        {activeTab === 7 && <PlaceholderPage title="Take Action" />}
      </Container>
    </Box>
  )
}
