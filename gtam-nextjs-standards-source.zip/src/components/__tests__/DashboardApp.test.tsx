import React from 'react'
import { render, screen } from '@testing-library/react'
import DashboardApp from '../DashboardApp'

describe('DashboardApp', () => {
  it('renders GTAM header', () => {
    render(<DashboardApp />)
    expect(screen.getByText('GTAM')).toBeInTheDocument()
  })
})
