export const FALLBACK_DASHBOARD_DATA = {
  lastUpdated: '02/12/2026, 3:22 PM',
  greeting: 'Hello Sri, CIB Payments',
  lob: 'CIB',
  product: 'ALL',
  insightCards: [
    {
      title: 'CPOF Compliance Violations Detected',
      subtitle: '37 CPOF applications have dependencies on non-CPOF systems',
      action: 'Review Violations',
      type: 'warning',
    },
    {
      title: 'Configuration Drift Detected',
      subtitle: '54 integrations discovered in production are not documented',
      action: 'Resolve Drift',
      type: 'warning',
    },
    {
      title: 'Critical Vulnerabilities Require Attention',
      subtitle: '82 WISI vulnerabilities identified across portfolio',
      action: 'Take Action',
      type: 'warning',
    },
    {
      title: 'Third-Party Infrastructure Growing',
      subtitle: '16.9% of applications run on 3rd party infrastructure',
      action: 'Take Action',
      type: 'info',
    },
    {
      title: 'Resilience Score Improved',
      subtitle: 'Application resilience increased 5 points this quarter',
      action: 'Take Action',
      type: 'success',
    },
  ],
  keyMetrics: [
    { label: 'Dependency Reliability', value: '78%', delta: '+3', tone: '#16a34a' },
    { label: 'CPOF Compliance', value: '88%', delta: '15 non-compliant', tone: '#dc2626' },
    { label: 'Total Assets', value: '776', delta: '+12', tone: '#16a34a' },
    { label: 'Patch Compliance', value: '89%', delta: '-3.2%', tone: '#b45309' },
    { label: 'WISI Vulnerabilities', value: '82', delta: '+15', tone: '#dc2626' },
    { label: 'Resilience Score', value: '87', delta: '+5', tone: '#16a34a' },
    { label: 'Configuration Drift', value: '16.1%', delta: '56 unmatched', tone: '#b45309' },
  ],
  ownership: {
    builtBy: [
      ['1st Party', 621, '80.0%'],
      ['3rd Party', 155, '20.0%'],
    ],
    runBy: [
      ['1st Party', 698, '89.9%'],
      ['3rd Party', 78, '10.1%'],
    ],
    runWhere: [
      ['1P Infrastructure', 645, '83.1%'],
      ['3P Infrastructure', 131, '16.9%'],
    ],
  },
  deployment: {
    totalApplications: 776,
    locationStats: [
      { label: 'On-Premise', value: 331, percent: '42.7%' },
      { label: 'Public Cloud', value: 80, percent: '10.3%' },
      { label: 'Hybrid', value: 65, percent: '8.4%' },
      { label: 'External 3P', value: 300, percent: '38.6%' },
    ],
    regionStats: [
      { region: 'US', value: 412, percent: '53.1%', datacenters: 3 },
      { region: 'EU', value: 198, percent: '25.5%', datacenters: 3 },
      { region: 'AP', value: 142, percent: '18.3%', datacenters: 3 },
      { region: 'LATAM', value: 24, percent: '3.1%', datacenters: 1 },
    ],
    computeUsage: [
      { label: 'Physical', value: 432, percent: '55.7%' },
      { label: 'Virtual', value: 189, percent: '24.4%' },
      { label: 'Container', value: 155, percent: '20.0%' },
    ],
    platformStats: [
      { name: 'GKP', count: 89 },
      { name: 'ECS', count: 42 },
      { name: 'EKS', count: 24 },
      { name: 'EC2', count: 156 },
      { name: 'VSI', count: 187 },
      { name: 'PSI', count: 98 },
      { name: 'Lambda', count: 0 },
      { name: 'Mainframe', count: 67 },
      { name: 'Tandem', count: 24 },
    ],
    providerStats: [
      { name: 'AWS', value: 48, detail: 'EC2, Lambda, ECS platforms' },
      { name: 'Google Cloud', value: 19, detail: 'GKE, GCP platforms' },
      { name: 'Azure', value: 13, detail: 'Virtual Machines, AKS' },
    ],
    datacenterConcentrations: [
      'US - 412 Applications',
      'EU - 198 Applications',
      'AP - 142 Applications',
      'LATAM - 24 Applications',
    ],
  },
}
