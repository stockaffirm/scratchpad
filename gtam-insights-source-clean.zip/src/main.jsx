import React from 'react'
import ReactDOM from 'react-dom/client'
import { CssBaseline, ThemeProvider, createTheme } from '@mui/material'
import App from './App'
import './styles.css'

const theme = createTheme({
  palette: {
    background: {
      default: '#f5f7fa',
      paper: '#ffffff',
    },
    text: {
      primary: '#1f2937',
      secondary: '#6b7280',
    },
    success: {
      main: '#18a957',
    },
    warning: {
      main: '#f59e0b',
    },
    error: {
      main: '#e11d48',
    },
  },
  typography: {
    fontFamily: '"Poppins", "Segoe UI", sans-serif',
    h4: {
      fontWeight: 700,
      fontSize: '1.55rem',
    },
    h6: {
      fontWeight: 700,
      fontSize: '1.1rem',
    },
    subtitle2: {
      fontWeight: 600,
    },
  },
  shape: {
    borderRadius: 10,
  },
})

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <App />
    </ThemeProvider>
  </React.StrictMode>,
)
